function getCurrentYear(){
    return new Date().getFullYear();
}

export default getCurrentYear;